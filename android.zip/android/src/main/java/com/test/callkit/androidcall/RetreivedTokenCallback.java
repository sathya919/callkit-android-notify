package com.test.callkit.androidcall;

public interface RetreivedTokenCallback {
    public void onTokenRetreived(String token);
}
