package com.test.callkit;

import android.util.Log;

public class CallKitVoip {

    public String echo(String value) {

        Log.d("CallKitVoip","called");
        return value;
    }
}
