package com.test.callkit;


import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.test.callkit.androidcall.VoipBackgroundService;



/**
 * NOTE: There can only be one service in each app that receives FCM messages. If multiple
 * are declared in the Manifest then the first one will be chosen.
 * <p>
 * In order to make this Java sample functional, you must remove the following from the Kotlin messaging
 * service in the AndroidManifest.xml:
 * <p>
 * <intent-filter>
 * <action android:name="com.google.firebase.MESSAGING_EVENT" />
 * </intent-filter>
 */
@SuppressLint("MissingFirebaseInstanceTokenRefresh")
public class MyFirebaseMessagingService extends FirebaseMessagingService {

  private static final String TAG = "MyFirebaseMsgService";

  public MyFirebaseMessagingService() {
    super();
    Log.d(TAG, "class instantiated");
  }

  @Override
  public void onNewToken(String token) {
    super.onNewToken(token);
    Log.e("newToken from FCM", token);
//Add your token in your sharepreferences.
    SharedPreferences sp = getSharedPreferences("My Pref" , Context.MODE_PRIVATE);
    sp.edit().putString("fcm_token",token).commit();
//    getSharedPreferences("_", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
  }


  /**
   * Called when message is received.
   *
   * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
   */

  @Override
  public void onMessageReceived(RemoteMessage remoteMessage) {
    Log.d(TAG, "received from postman " + remoteMessage.getData());

    if (remoteMessage.getData().containsKey("type") && remoteMessage.getData().get("type").equals("call")) {
      show_call_notification(remoteMessage.getData().get("connectionId"), remoteMessage.getData().get("username"));
    }

    if (remoteMessage.getData().containsKey("type") && remoteMessage.getData().get("type").equals("stopCall")) {

    }
    show_call_notification(remoteMessage.getData().get("connectionId"), remoteMessage.getData().get("username"));


  }


  public void show_call_notification (String connectionId, String username) {
    Intent voip_service = new Intent(getApplicationContext(), VoipBackgroundService.class);
    voip_service.putExtra("connectionId", connectionId);
    voip_service.putExtra("username", username);
    Log.d("show_call_notification", "called");

    if (!isServiceRunning("com.test.callkit.androidcall.VoipBackgroundService")) {
      try {
        getApplicationContext().startService(voip_service);
      } catch (Exception e) {
      }
    } else {
      try {
        getApplicationContext().stopService(voip_service);
      } catch (Exception e) {
      }
      try {
        getApplicationContext().startService(voip_service);
      } catch (Exception e) {
        Log.d("sip_call_init", e.toString());
      }
    }

  }

  private boolean isServiceRunning(String service_name){
    ActivityManager manager = (ActivityManager) getApplicationContext().getSystemService(getApplicationContext().ACTIVITY_SERVICE);
    for (ActivityManager.RunningServiceInfo service_running : manager.getRunningServices(Integer.MAX_VALUE)) {
      if (service_name.equals(service_running.service.getClassName())) {
        return true;
      }
    }
    return false;
  }
}
